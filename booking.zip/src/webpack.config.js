const path = require('path');

module.exports = {
  // other configurations
  resolve: {
    fallback: {
      timers: false,
    },
  },
  // other configurations
};
